const openAIAPIKey = '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';
const openAIAPIKey2 = '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';
